# Quick Start Guide

## Prerequisites Check
Before running tests, ensure you have:
- ✅ Java 11+ installed (`java -version`)
- ✅ Maven installed (`mvn -version`)
- ✅ Chrome browser installed
- ✅ Internet connection active

## 5-Minute Setup

### Step 1: Open Project in IDE
```bash
# Open Terminal/Command Prompt
cd CalleyTeamsFullSetup
```

### Step 2: Install Dependencies
```bash
mvn clean install
```
*This downloads all required libraries (~2-3 minutes)*

### Step 3: Run Your First Test
```bash
mvn clean test -Dtest=FullSetupTest
```

That's it! The test will:
1. Open Chrome browser
2. Register a new user
3. Login
4. Add an agent
5. Upload CSV file
6. Generate report

## View Test Report
After test execution:
```bash
# Windows
start test-output\Test-Report-*.html

# Mac
open test-output/Test-Report-*.html

# Linux
xdg-open test-output/Test-Report-*.html
```

## Run Different Tests

### Run All Tests
```bash
mvn clean test
```

### Run Specific Test
```bash
# Registration only
mvn test -Dtest=RegistrationTest

# Login only
mvn test -Dtest=LoginTest

# Agent management
mvn test -Dtest=AgentTest

# CSV upload
mvn test -Dtest=CSVUploadTest
```

### Use Run Scripts (Easier!)

**Windows:**
```cmd
run-tests.bat
```

**Linux/Mac:**
```bash
./run-tests.sh
```

## Common Issues & Solutions

### ❌ "mvn command not found"
**Solution**: Install Maven from https://maven.apache.org/download.cgi

### ❌ "Java version not compatible"
**Solution**: Install Java 11+ from https://www.oracle.com/java/technologies/downloads/

### ❌ "Tests are failing"
**Solution**: 
1. Check internet connection
2. Verify Chrome browser is installed
3. Update test data in `src/test/resources/testdata/data.properties`

### ❌ "Cannot find CSV file"
**Solution**: CSV file is already included at `src/test/resources/testdata/SampleFile.csv`

## Project Structure Quick Reference
```
CalleyTeamsFullSetup/
├── src/main/java/          → Page Objects & Utilities
├── src/test/java/          → Test Classes
├── src/test/resources/     → Config & Test Data
├── test-output/            → Test Reports (generated)
├── pom.xml                 → Maven configuration
├── testng.xml              → TestNG suite
└── README.md               → Full documentation
```

## Next Steps

1. **Review the code**: Check page objects and test classes
2. **Customize test data**: Edit `src/test/resources/testdata/data.properties`
3. **Add more tests**: Create new test classes extending `BaseTest`
4. **Run in different browsers**: Change `browser` parameter in testng.xml

## Need Help?

📖 Read full documentation: `README.md`
📧 Contact: hr@cstech.in

---

**Happy Testing! 🚀**
