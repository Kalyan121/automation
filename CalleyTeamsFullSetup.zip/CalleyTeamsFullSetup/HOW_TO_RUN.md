# How to Run the Calley Automation Testing Project

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Installation](#installation)
3. [Running Tests](#running-tests)
4. [Viewing Reports](#viewing-reports)
5. [Configuration](#configuration)
6. [Recording Video](#recording-video)
7. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Software
1. **Java Development Kit (JDK) 11 or higher**
   - Download: https://www.oracle.com/java/technologies/downloads/
   - Verify installation: `java -version`

2. **Apache Maven 3.6+**
   - Download: https://maven.apache.org/download.cgi
   - Verify installation: `mvn -version`

3. **Google Chrome Browser** (Latest version)
   - Download: https://www.google.com/chrome/

4. **IDE (Choose one)**
   - IntelliJ IDEA (Recommended): https://www.jetbrains.com/idea/download/
   - Eclipse: https://www.eclipse.org/downloads/
   - VS Code with Java extensions

### Check Your Setup
```bash
# Check Java version
java -version
# Should show: java version "11" or higher

# Check Maven version
mvn -version
# Should show: Apache Maven 3.6.x or higher

# Check if Chrome is installed
# Open Chrome and check version: Settings → About Chrome
```

---

## Installation

### Step 1: Get the Project
```bash
# If you have the ZIP file
unzip CalleyTeamsFullSetup.zip
cd CalleyTeamsFullSetup

# OR if using Git
git clone <repository-url>
cd CalleyTeamsFullSetup
```

### Step 2: Import into IDE

#### For IntelliJ IDEA:
1. Open IntelliJ IDEA
2. Click: `File → Open`
3. Navigate to `CalleyTeamsFullSetup` folder
4. Select the folder and click `OK`
5. IntelliJ will automatically detect it as a Maven project
6. Wait for Maven to download dependencies (check bottom-right progress bar)

#### For Eclipse:
1. Open Eclipse
2. Click: `File → Import`
3. Select: `Maven → Existing Maven Projects`
4. Click `Next`
5. Browse to `CalleyTeamsFullSetup` folder
6. Click `Finish`
7. Wait for Maven to download dependencies

#### For VS Code:
1. Open VS Code
2. Install "Extension Pack for Java" if not already installed
3. Click: `File → Open Folder`
4. Select `CalleyTeamsFullSetup` folder
5. VS Code will detect Maven project automatically

### Step 3: Download Dependencies
```bash
# Navigate to project directory
cd CalleyTeamsFullSetup

# Download all dependencies
mvn clean install

# This will:
# - Download Selenium WebDriver
# - Download TestNG
# - Download all other required libraries
# - Compile the project
# Takes 2-5 minutes depending on internet speed
```

---

## Running Tests

### Method 1: Using Maven Commands (Recommended)

#### Run Complete End-to-End Test
```bash
mvn clean test -Dtest=FullSetupTest
```
*This runs: Registration → Login → Add Agent → CSV Upload*

#### Run All Tests
```bash
mvn clean test
```
*Runs all test classes in the project*

#### Run Specific Test Classes
```bash
# Registration tests only
mvn clean test -Dtest=RegistrationTest

# Login tests only
mvn clean test -Dtest=LoginTest

# Agent management tests only
mvn clean test -Dtest=AgentTest

# CSV upload tests only
mvn clean test -Dtest=CSVUploadTest
```

#### Run Tests with Different Browsers
```bash
# Run with Chrome (default)
mvn clean test -Dbrowser=chrome

# Run with Firefox
mvn clean test -Dbrowser=firefox

# Run with Edge
mvn clean test -Dbrowser=edge
```

### Method 2: Using TestNG XML

#### From Command Line
```bash
mvn clean test -DsuiteXmlFile=testng.xml
```

#### From IDE
1. **IntelliJ IDEA**:
   - Right-click on `testng.xml`
   - Select `Run 'testng.xml'`

2. **Eclipse**:
   - Right-click on `testng.xml`
   - Select `Run As → TestNG Suite`

### Method 3: Using Run Scripts

#### Windows
```cmd
# Double-click run-tests.bat
# OR from command prompt:
run-tests.bat
```

#### Linux/Mac
```bash
# Make it executable (first time only)
chmod +x run-tests.sh

# Run the script
./run-tests.sh
```

*The script provides an interactive menu to choose which tests to run.*

### Method 4: From IDE (Individual Tests)

#### IntelliJ IDEA
1. Open test class (e.g., `FullSetupTest.java`)
2. Right-click on test method or class
3. Select `Run 'FullSetupTest'`

#### Eclipse
1. Open test class
2. Right-click on test method or class
3. Select `Run As → TestNG Test`

---

## Viewing Reports

### ExtentReports (Detailed HTML Report)
After test execution:
```bash
# Location
test-output/Test-Report-<timestamp>.html

# Open in browser
# Windows: double-click the file
# Mac: open test-output/Test-Report-*.html
# Linux: xdg-open test-output/Test-Report-*.html
```

**Report Contains:**
- ✅ Test pass/fail status
- 📝 Step-by-step execution logs
- ⏱️ Execution time for each test
- 💻 System information
- 📊 Test statistics

### TestNG Reports (Standard)
```bash
# Location
test-output/index.html
test-output/emailable-report.html

# Open in browser
```

### Console Output
During test execution, you'll see:
```
[INFO] Running FullSetupTest
========== STEP 1: USER REGISTRATION ==========
[INFO] Test Data - Email: john.doe.1234567890@test.com
[PASS] Registration page loaded successfully
[PASS] Registration form filled successfully
[PASS] ✓ User registered successfully
========== STEP 2: USER LOGIN ==========
...
```

---

## Configuration

### Test Data Configuration
Edit: `src/test/resources/testdata/data.properties`

```properties
# Change these values
firstName=YourFirstName
lastName=YourLastName
email=your.email@test.com
password=YourPassword@123
company=Your Company Name
agentName=Your Agent Name
agentEmail=agent@test.com
listName=Your List Name
```

### Application URLs
Edit: `src/test/resources/config.properties`

```properties
# Change browser if needed
browser=chrome

# Application URLs (usually don't need to change)
baseUrl=https://app.getcalley.com
registrationUrl=https://app.getcalley.com/registration.aspx
loginUrl=https://app.getcalley.com/Login.aspx
```

### Browser Configuration
In `testng.xml`, change browser parameter:
```xml
<parameter name="browser" value="chrome"/>
<!-- Change to: firefox or edge if needed -->
```

---

## Recording Video

### Step 1: Choose Recording Software

**Windows:**
- Xbox Game Bar (Built-in): Press `Win + G`
- OBS Studio: https://obsproject.com/

**Mac:**
- QuickTime Player (Built-in): File → New Screen Recording
- OBS Studio: https://obsproject.com/

**Linux:**
- SimpleScreenRecorder
- OBS Studio: https://obsproject.com/

### Step 2: Start Recording

1. Open your screen recording software
2. Select recording area (full screen or window)
3. Start recording
4. Switch to terminal/IDE

### Step 3: Run Test
```bash
mvn clean test -Dtest=FullSetupTest
```

### Step 4: What to Record
Capture:
- ✅ Browser opening automatically
- ✅ Registration form being filled
- ✅ User login process
- ✅ Agent being added
- ✅ CSV file upload
- ✅ Console output showing test steps
- ✅ Final test report

### Step 5: Stop and Save
1. Stop recording
2. Save video file
3. Upload to Google Drive
4. Set sharing to "Anyone with the link can view"
5. Copy share link

---

## Troubleshooting

### ❌ Problem: "mvn: command not found"
**Solution:**
1. Download Maven from https://maven.apache.org/download.cgi
2. Extract to a folder (e.g., C:\maven)
3. Add to PATH:
   - Windows: System Properties → Environment Variables → Add to PATH
   - Mac/Linux: Add to `.bashrc` or `.zshrc`:
     ```bash
     export PATH=/path/to/maven/bin:$PATH
     ```
4. Restart terminal
5. Verify: `mvn -version`

### ❌ Problem: "Java version not compatible"
**Solution:**
1. Install JDK 11 or higher
2. Set JAVA_HOME environment variable
3. Verify: `java -version`

### ❌ Problem: Tests fail with "Element not found"
**Solution:**
1. Increase timeout in `config.properties`:
   ```properties
   explicitWait=60
   ```
2. Check internet connection
3. Verify website is accessible: https://app.getcalley.com

### ❌ Problem: "WebDriver not found"
**Solution:**
- Project uses WebDriverManager - it downloads drivers automatically
- Ensure internet connection is active
- If behind proxy, configure proxy settings

### ❌ Problem: CSV file not found
**Solution:**
```bash
# Verify file exists
ls src/test/resources/testdata/SampleFile.csv

# File should be present - if not, check extraction
```

### ❌ Problem: Login tests fail
**Solution:**
1. First run Registration test to create account
2. Update `loginEmail` and `loginPassword` in `data.properties`
3. Or use existing valid credentials

### ❌ Problem: Chrome not opening
**Solution:**
1. Verify Chrome is installed
2. Update Chrome to latest version
3. Try different browser:
   ```bash
   mvn test -Dbrowser=firefox
   ```

### ❌ Problem: Dependencies not downloading
**Solution:**
```bash
# Clear Maven cache
mvn dependency:purge-local-repository

# Re-download
mvn clean install -U
```

---

## Additional Commands

### Clean Project
```bash
mvn clean
```

### Compile Project
```bash
mvn compile
```

### Run Tests Skipping Compilation
```bash
mvn test
```

### Generate Site Documentation
```bash
mvn site
```

### Package Project
```bash
mvn package
```

---

## Tips for Success

1. **First Time Setup**: Run `mvn clean install` first
2. **Internet Required**: Tests need internet to access Calley website
3. **Don't Close Browser**: Let tests complete - browser will close automatically
4. **Check Reports**: Always check HTML reports after execution
5. **Update Test Data**: Use unique emails for each registration
6. **Sequential Execution**: Run FullSetupTest first for complete flow

---

## Getting Help

📖 **Full Documentation**: See `README.md`

📧 **Email Support**: hr@cstech.in

💡 **Quick Start**: See `QUICK_START.md`

---

**Happy Testing! 🚀**

*Last Updated: February 2026*
