#!/bin/bash

echo "========================================"
echo " Calley Teams Automation Test Runner"
echo "========================================"
echo ""
echo "Select test to run:"
echo "1. Run All Tests"
echo "2. Run Full Setup Test (End-to-End)"
echo "3. Run Registration Tests Only"
echo "4. Run Login Tests Only"
echo "5. Run Agent Tests Only"
echo "6. Run CSV Upload Tests Only"
echo "7. Clean and Run All Tests"
echo ""
read -p "Enter your choice (1-7): " choice

case $choice in
    1)
        echo "Running all tests..."
        mvn clean test
        ;;
    2)
        echo "Running Full Setup Test..."
        mvn clean test -Dtest=FullSetupTest
        ;;
    3)
        echo "Running Registration Tests..."
        mvn clean test -Dtest=RegistrationTest
        ;;
    4)
        echo "Running Login Tests..."
        mvn clean test -Dtest=LoginTest
        ;;
    5)
        echo "Running Agent Tests..."
        mvn clean test -Dtest=AgentTest
        ;;
    6)
        echo "Running CSV Upload Tests..."
        mvn clean test -Dtest=CSVUploadTest
        ;;
    7)
        echo "Cleaning and running all tests..."
        mvn clean install
        mvn test
        ;;
    *)
        echo "Invalid choice. Please run the script again."
        exit 1
        ;;
esac

echo ""
echo "========================================"
echo " Test execution completed!"
echo " Check test-output folder for reports"
echo "========================================"
