package com.calley.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ExtentReportManager for generating test execution reports
 */
public class ExtentReportManager {
    private static ExtentReports extent;
    private static ExtentTest test;
    private static String reportFileName = "Test-Report-" + 
            new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()) + ".html";
    private static String reportFilePath = System.getProperty("user.dir") + "/test-output/" + reportFileName;

    /**
     * Initialize Extent Reports
     */
    public static void initReports() {
        if (extent == null) {
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportFilePath);
            
            // Configure report
            sparkReporter.config().setDocumentTitle("Calley Automation Test Report");
            sparkReporter.config().setReportName("Calley Teams Full Setup Automation");
            sparkReporter.config().setTheme(Theme.STANDARD);
            sparkReporter.config().setEncoding("utf-8");
            
            // Initialize ExtentReports
            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);
            
            // Add system information
            extent.setSystemInfo("Application", "Calley Teams");
            extent.setSystemInfo("Operating System", System.getProperty("os.name"));
            extent.setSystemInfo("User Name", System.getProperty("user.name"));
            extent.setSystemInfo("Java Version", System.getProperty("java.version"));
            extent.setSystemInfo("Test Environment", "QA");
        }
    }

    /**
     * Create a new test in the report
     */
    public static ExtentTest createTest(String testName, String description) {
        test = extent.createTest(testName, description);
        return test;
    }

    /**
     * Get current test instance
     */
    public static ExtentTest getTest() {
        return test;
    }

    /**
     * Log info message
     */
    public static void logInfo(String message) {
        if (test != null) {
            test.log(Status.INFO, message);
        }
    }

    /**
     * Log pass message
     */
    public static void logPass(String message) {
        if (test != null) {
            test.log(Status.PASS, message);
        }
    }

    /**
     * Log fail message
     */
    public static void logFail(String message) {
        if (test != null) {
            test.log(Status.FAIL, message);
        }
    }

    /**
     * Log skip message
     */
    public static void logSkip(String message) {
        if (test != null) {
            test.log(Status.SKIP, message);
        }
    }

    /**
     * Log warning message
     */
    public static void logWarning(String message) {
        if (test != null) {
            test.log(Status.WARNING, message);
        }
    }

    /**
     * Flush and write reports
     */
    public static void flushReports() {
        if (extent != null) {
            extent.flush();
            System.out.println("Test Report generated at: " + reportFilePath);
        }
    }
}
