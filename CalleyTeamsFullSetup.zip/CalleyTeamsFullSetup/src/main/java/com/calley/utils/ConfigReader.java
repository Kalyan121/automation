package com.calley.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader class to read configuration from properties file
 */
public class ConfigReader {
    private Properties properties;
    private static final String CONFIG_FILE_PATH = "src/test/resources/config.properties";

    public ConfigReader() {
        properties = new Properties();
        try {
            FileInputStream fis = new FileInputStream(CONFIG_FILE_PATH);
            properties.load(fis);
            fis.close();
        } catch (IOException e) {
            System.out.println("Error loading config file: " + e.getMessage());
            // Set default values if file not found
            setDefaultProperties();
        }
    }

    /**
     * Set default properties if config file is not found
     */
    private void setDefaultProperties() {
        properties.setProperty("browser", "chrome");
        properties.setProperty("baseUrl", "https://app.getcalley.com");
        properties.setProperty("registrationUrl", "https://app.getcalley.com/registration.aspx");
        properties.setProperty("loginUrl", "https://app.getcalley.com/Login.aspx");
        properties.setProperty("implicitWait", "10");
        properties.setProperty("explicitWait", "30");
    }

    /**
     * Get property value by key
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    /**
     * Get browser name
     */
    public String getBrowser() {
        return properties.getProperty("browser", "chrome");
    }

    /**
     * Get base URL
     */
    public String getBaseUrl() {
        return properties.getProperty("baseUrl", "https://app.getcalley.com");
    }

    /**
     * Get registration URL
     */
    public String getRegistrationUrl() {
        return properties.getProperty("registrationUrl", "https://app.getcalley.com/registration.aspx");
    }

    /**
     * Get login URL
     */
    public String getLoginUrl() {
        return properties.getProperty("loginUrl", "https://app.getcalley.com/Login.aspx");
    }

    /**
     * Get implicit wait time
     */
    public int getImplicitWait() {
        return Integer.parseInt(properties.getProperty("implicitWait", "10"));
    }

    /**
     * Get explicit wait time
     */
    public int getExplicitWait() {
        return Integer.parseInt(properties.getProperty("explicitWait", "30"));
    }
}
