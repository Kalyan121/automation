package com.calley.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * TestDataReader class to read test data from properties file
 */
public class TestDataReader {
    private Properties testData;
    private static final String TEST_DATA_FILE_PATH = "src/test/resources/testdata/data.properties";

    public TestDataReader() {
        testData = new Properties();
        try {
            FileInputStream fis = new FileInputStream(TEST_DATA_FILE_PATH);
            testData.load(fis);
            fis.close();
        } catch (IOException e) {
            System.out.println("Error loading test data file: " + e.getMessage());
            setDefaultTestData();
        }
    }

    /**
     * Set default test data if file is not found
     */
    private void setDefaultTestData() {
        testData.setProperty("firstName", "John");
        testData.setProperty("lastName", "Doe");
        testData.setProperty("email", "john.doe." + System.currentTimeMillis() + "@test.com");
        testData.setProperty("phone", "1234567890");
        testData.setProperty("password", "Test@1234");
        testData.setProperty("company", "Test Company");
        testData.setProperty("agentName", "Test Agent");
        testData.setProperty("agentEmail", "agent." + System.currentTimeMillis() + "@test.com");
        testData.setProperty("listName", "Test List");
    }

    /**
     * Get test data value by key
     */
    public String getTestData(String key) {
        return testData.getProperty(key);
    }

    /**
     * Get first name
     */
    public String getFirstName() {
        return testData.getProperty("firstName", "John");
    }

    /**
     * Get last name
     */
    public String getLastName() {
        return testData.getProperty("lastName", "Doe");
    }

    /**
     * Get email with timestamp to ensure uniqueness
     */
    public String getEmail() {
        String baseEmail = testData.getProperty("email", "test@test.com");
        String[] parts = baseEmail.split("@");
        return parts[0] + "." + System.currentTimeMillis() + "@" + parts[1];
    }

    /**
     * Get phone number
     */
    public String getPhone() {
        return testData.getProperty("phone", "1234567890");
    }

    /**
     * Get password
     */
    public String getPassword() {
        return testData.getProperty("password", "Test@1234");
    }

    /**
     * Get company name
     */
    public String getCompany() {
        return testData.getProperty("company", "Test Company");
    }

    /**
     * Get agent name
     */
    public String getAgentName() {
        return testData.getProperty("agentName", "Test Agent");
    }

    /**
     * Get agent email with timestamp
     */
    public String getAgentEmail() {
        String baseEmail = testData.getProperty("agentEmail", "agent@test.com");
        String[] parts = baseEmail.split("@");
        return parts[0] + "." + System.currentTimeMillis() + "@" + parts[1];
    }

    /**
     * Get list name
     */
    public String getListName() {
        return testData.getProperty("listName", "Test List");
    }
}
