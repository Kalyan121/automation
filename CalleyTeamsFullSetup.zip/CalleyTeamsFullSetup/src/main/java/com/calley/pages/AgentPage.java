package com.calley.pages;

import com.calley.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * AgentPage class - Page Object Model for Agent management page
 * Contains all locators and methods for adding agents
 */
public class AgentPage extends BasePage {
    
    // Locators
    private By agentsMenuLink = By.xpath("//a[contains(text(), 'Agent') or contains(@href, 'agent')]");
    private By addAgentButton = By.xpath("//button[contains(text(), 'Add Agent') or contains(text(), 'New Agent')]");
    private By agentNameField = By.id("txtAgentName");
    private By agentEmailField = By.id("txtAgentEmail");
    private By agentPhoneField = By.id("txtAgentPhone");
    private By saveAgentButton = By.id("btnSaveAgent");
    private By successMessage = By.xpath("//div[contains(@class, 'success') or contains(text(), 'successfully')]");
    
    // Alternative locators
    private By agentNameFieldAlt = By.name("agentName");
    private By agentEmailFieldAlt = By.name("agentEmail");
    private By agentPhoneFieldAlt = By.name("agentPhone");
    private By saveButtonAlt = By.xpath("//button[@type='submit' or contains(text(), 'Save') or contains(text(), 'Add')]");
    
    // Agent list locators
    private By agentTable = By.xpath("//table[contains(@class, 'agent') or contains(@id, 'agent')]");
    private By agentsList = By.xpath("//div[contains(@class, 'agent-list')]");
    
    public AgentPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Navigate to agents page
     */
    public void navigateToAgentsPage() {
        try {
            clickElement(agentsMenuLink);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Could not find agents menu link, might already be on agents page");
        }
    }

    /**
     * Click add agent button
     */
    public void clickAddAgent() {
        try {
            clickElement(addAgentButton);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Add agent button not found");
        }
    }

    /**
     * Enter agent name
     */
    public void enterAgentName(String name) {
        try {
            enterText(agentNameField, name);
        } catch (Exception e) {
            enterText(agentNameFieldAlt, name);
        }
    }

    /**
     * Enter agent email
     */
    public void enterAgentEmail(String email) {
        try {
            enterText(agentEmailField, email);
        } catch (Exception e) {
            enterText(agentEmailFieldAlt, email);
        }
    }

    /**
     * Enter agent phone
     */
    public void enterAgentPhone(String phone) {
        try {
            enterText(agentPhoneField, phone);
        } catch (Exception e) {
            enterText(agentPhoneFieldAlt, phone);
        }
    }

    /**
     * Click save agent button
     */
    public void clickSaveAgent() {
        try {
            clickElement(saveAgentButton);
        } catch (Exception e) {
            clickElement(saveButtonAlt);
        }
        waitFor(3);
    }

    /**
     * Add a new agent with all details
     */
    public void addAgent(String name, String email, String phone) {
        clickAddAgent();
        enterAgentName(name);
        enterAgentEmail(email);
        enterAgentPhone(phone);
        clickSaveAgent();
    }

    /**
     * Add a new agent with name and email only
     */
    public void addAgent(String name, String email) {
        clickAddAgent();
        enterAgentName(name);
        enterAgentEmail(email);
        clickSaveAgent();
    }

    /**
     * Verify agent added successfully
     */
    public boolean isAgentAddedSuccessfully() {
        try {
            waitFor(2);
            return isElementDisplayed(successMessage) || 
                   isElementDisplayed(agentTable) || 
                   isElementDisplayed(agentsList);
        } catch (Exception e) {
            return isElementDisplayed(agentTable) || isElementDisplayed(agentsList);
        }
    }

    /**
     * Verify agents page loaded
     */
    public boolean isAgentsPageLoaded() {
        try {
            String currentUrl = getCurrentUrl().toLowerCase();
            return currentUrl.contains("agent") || 
                   isElementDisplayed(addAgentButton) ||
                   isElementDisplayed(agentTable) ||
                   isElementDisplayed(agentsList);
        } catch (Exception e) {
            return getCurrentUrl().toLowerCase().contains("agent");
        }
    }

    /**
     * Get current page URL
     */
    public String getPageUrl() {
        return getCurrentUrl();
    }

    /**
     * Get success message text
     */
    public String getSuccessMessage() {
        try {
            return getText(successMessage);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Check if agent exists in list by email
     */
    public boolean isAgentInList(String email) {
        try {
            By agentInList = By.xpath("//td[contains(text(), '" + email + "')] | //div[contains(text(), '" + email + "')]");
            return isElementDisplayed(agentInList);
        } catch (Exception e) {
            return false;
        }
    }
}
