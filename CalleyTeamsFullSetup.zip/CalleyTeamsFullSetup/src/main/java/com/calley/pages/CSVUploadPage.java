package com.calley.pages;

import com.calley.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * CSVUploadPage class - Page Object Model for CSV Upload/Power Import page
 * Contains all locators and methods for uploading CSV files
 */
public class CSVUploadPage extends BasePage {
    
    // Locators
    private By callListMenu = By.xpath("//a[contains(text(), 'Call List') or contains(@href, 'calllist')]");
    private By powerImportOption = By.xpath("//a[contains(text(), 'Power Import') or contains(@href, 'powerimport') or contains(@href, 'import')]");
    private By listNameField = By.id("txtListName");
    private By fileUploadInput = By.xpath("//input[@type='file']");
    private By selectAgentsDropdown = By.id("ddlAgents");
    private By uploadButton = By.xpath("//button[contains(text(), 'Upload') or contains(text(), 'Choose File')]");
    private By importButton = By.xpath("//button[contains(text(), 'Import') or @id='btnImport']");
    private By successMessage = By.xpath("//div[contains(@class, 'success') or contains(text(), 'successfully') or contains(text(), 'imported')]");
    
    // Alternative locators
    private By listNameFieldAlt = By.name("listName");
    private By nextButton = By.xpath("//button[contains(text(), 'Next') or contains(text(), 'Continue')]");
    
    // Field mapping locators
    private By firstNameMapping = By.xpath("//select[contains(@id, 'firstName') or contains(@name, 'firstName')]");
    private By lastNameMapping = By.xpath("//select[contains(@id, 'lastName') or contains(@name, 'lastName')]");
    private By phoneMapping = By.xpath("//select[contains(@id, 'phone') or contains(@name, 'phone')]");
    private By emailMapping = By.xpath("//select[contains(@id, 'email') or contains(@name, 'email')]");
    
    public CSVUploadPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Navigate to Call List menu
     */
    public void navigateToCallList() {
        try {
            waitFor(2);
            clickElement(callListMenu);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Could not find Call List menu");
        }
    }

    /**
     * Navigate to Power Import option
     */
    public void navigateToPowerImport() {
        try {
            navigateToCallList();
            clickElement(powerImportOption);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Could not find Power Import option, trying direct navigation");
            driver.get(getCurrentUrl().replace("dashboard", "powerimport"));
            waitFor(2);
        }
    }

    /**
     * Enter list name
     */
    public void enterListName(String listName) {
        try {
            enterText(listNameField, listName);
        } catch (Exception e) {
            enterText(listNameFieldAlt, listName);
        }
    }

    /**
     * Upload CSV file
     */
    public void uploadCSVFile(String filePath) {
        try {
            WebElement fileInput = driver.findElement(fileUploadInput);
            fileInput.sendKeys(filePath);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("File upload failed: " + e.getMessage());
        }
    }

    /**
     * Select agents from dropdown
     */
    public void selectAgents(String agentName) {
        try {
            selectByVisibleText(selectAgentsDropdown, agentName);
        } catch (Exception e) {
            System.out.println("Could not select agent: " + e.getMessage());
        }
    }

    /**
     * Select agent by index
     */
    public void selectAgentByIndex(int index) {
        try {
            selectByIndex(selectAgentsDropdown, index);
        } catch (Exception e) {
            System.out.println("Could not select agent by index: " + e.getMessage());
        }
    }

    /**
     * Click upload button
     */
    public void clickUpload() {
        try {
            clickElement(uploadButton);
            waitFor(3);
        } catch (Exception e) {
            System.out.println("Upload button not found");
        }
    }

    /**
     * Click next/continue button
     */
    public void clickNext() {
        try {
            clickElement(nextButton);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Next button not found");
        }
    }

    /**
     * Map CSV fields
     */
    public void mapFields() {
        try {
            // Map first name
            if (isElementDisplayed(firstNameMapping)) {
                selectByIndex(firstNameMapping, 1);
            }
            
            // Map last name
            if (isElementDisplayed(lastNameMapping)) {
                selectByIndex(lastNameMapping, 2);
            }
            
            // Map phone
            if (isElementDisplayed(phoneMapping)) {
                selectByIndex(phoneMapping, 3);
            }
            
            // Map email
            if (isElementDisplayed(emailMapping)) {
                selectByIndex(emailMapping, 4);
            }
            
            waitFor(1);
        } catch (Exception e) {
            System.out.println("Field mapping not required or failed: " + e.getMessage());
        }
    }

    /**
     * Click import button
     */
    public void clickImport() {
        try {
            clickElement(importButton);
            waitFor(3);
        } catch (Exception e) {
            System.out.println("Import button not found");
        }
    }

    /**
     * Complete CSV upload process
     */
    public void uploadCSV(String listName, String csvFilePath) {
        navigateToPowerImport();
        enterListName(listName);
        uploadCSVFile(csvFilePath);
        clickNext();
        selectAgentByIndex(1); // Select first agent
        clickNext();
        mapFields();
        clickImport();
    }

    /**
     * Complete CSV upload process with agent selection
     */
    public void uploadCSVWithAgent(String listName, String csvFilePath, String agentName) {
        navigateToPowerImport();
        enterListName(listName);
        selectAgents(agentName);
        uploadCSVFile(csvFilePath);
        clickNext();
        mapFields();
        clickImport();
    }

    /**
     * Verify CSV upload successful
     */
    public boolean isUploadSuccessful() {
        try {
            waitFor(3);
            return isElementDisplayed(successMessage) || 
                   getCurrentUrl().contains("success") ||
                   getCurrentUrl().contains("calllist");
        } catch (Exception e) {
            return getCurrentUrl().contains("success") || getCurrentUrl().contains("calllist");
        }
    }

    /**
     * Verify power import page loaded
     */
    public boolean isPowerImportPageLoaded() {
        try {
            String currentUrl = getCurrentUrl().toLowerCase();
            return currentUrl.contains("import") || 
                   currentUrl.contains("upload") ||
                   isElementDisplayed(listNameField) ||
                   isElementDisplayed(fileUploadInput);
        } catch (Exception e) {
            String currentUrl = getCurrentUrl().toLowerCase();
            return currentUrl.contains("import") || currentUrl.contains("upload");
        }
    }

    /**
     * Get current page URL
     */
    public String getPageUrl() {
        return getCurrentUrl();
    }

    /**
     * Get success message text
     */
    public String getSuccessMessage() {
        try {
            return getText(successMessage);
        } catch (Exception e) {
            return "";
        }
    }
}
