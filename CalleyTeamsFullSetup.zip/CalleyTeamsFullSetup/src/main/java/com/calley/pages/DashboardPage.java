package com.calley.pages;

import com.calley.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * DashboardPage class - Page Object Model for Dashboard/Home page
 * Contains all locators and methods for dashboard navigation
 */
public class DashboardPage extends BasePage {
    
    // Locators
    private By dashboardTitle = By.xpath("//h1[contains(text(), 'Dashboard')] | //div[contains(@class, 'dashboard-title')]");
    private By userProfileMenu = By.xpath("//div[contains(@class, 'user-profile')] | //a[contains(@class, 'profile')]");
    private By logoutButton = By.xpath("//a[contains(text(), 'Logout') or contains(text(), 'Sign Out')]");
    
    // Navigation menu items
    private By homeMenu = By.xpath("//a[contains(text(), 'Home') or contains(@href, 'home')]");
    private By callListMenu = By.xpath("//a[contains(text(), 'Call List') or contains(@href, 'calllist')]");
    private By agentsMenu = By.xpath("//a[contains(text(), 'Agent') or contains(@href, 'agent')]");
    private By reportsMenu = By.xpath("//a[contains(text(), 'Report') or contains(@href, 'report')]");
    private By settingsMenu = By.xpath("//a[contains(text(), 'Setting') or contains(@href, 'setting')]");
    
    // Welcome message
    private By welcomeMessage = By.xpath("//div[contains(text(), 'Welcome')] | //h2[contains(text(), 'Welcome')]");
    
    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Verify dashboard page loaded
     */
    public boolean isDashboardLoaded() {
        try {
            waitFor(3);
            String currentUrl = getCurrentUrl().toLowerCase();
            return currentUrl.contains("dashboard") || 
                   currentUrl.contains("home") || 
                   currentUrl.contains("main") ||
                   isElementDisplayed(dashboardTitle) ||
                   isElementDisplayed(welcomeMessage);
        } catch (Exception e) {
            String currentUrl = getCurrentUrl().toLowerCase();
            return !currentUrl.contains("login") && 
                   (currentUrl.contains("dashboard") || 
                    currentUrl.contains("home") || 
                    currentUrl.contains("main"));
        }
    }

    /**
     * Get dashboard title
     */
    public String getDashboardTitle() {
        try {
            return getText(dashboardTitle);
        } catch (Exception e) {
            return getPageTitle();
        }
    }

    /**
     * Navigate to Call List
     */
    public void navigateToCallList() {
        clickElement(callListMenu);
        waitFor(2);
    }

    /**
     * Navigate to Agents
     */
    public void navigateToAgents() {
        clickElement(agentsMenu);
        waitFor(2);
    }

    /**
     * Navigate to Reports
     */
    public void navigateToReports() {
        try {
            clickElement(reportsMenu);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Reports menu not found");
        }
    }

    /**
     * Navigate to Settings
     */
    public void navigateToSettings() {
        try {
            clickElement(settingsMenu);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Settings menu not found");
        }
    }

    /**
     * Click user profile menu
     */
    public void clickUserProfile() {
        try {
            clickElement(userProfileMenu);
            waitFor(1);
        } catch (Exception e) {
            System.out.println("User profile menu not found");
        }
    }

    /**
     * Logout from application
     */
    public void logout() {
        try {
            clickUserProfile();
            clickElement(logoutButton);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Logout failed: " + e.getMessage());
        }
    }

    /**
     * Check if welcome message is displayed
     */
    public boolean isWelcomeMessageDisplayed() {
        try {
            return isElementDisplayed(welcomeMessage);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get current page URL
     */
    public String getPageUrl() {
        return getCurrentUrl();
    }

    /**
     * Verify user is logged in
     */
    public boolean isUserLoggedIn() {
        return isDashboardLoaded();
    }
}
