package com.calley.pages;

import com.calley.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * LoginPage class - Page Object Model for Login page
 * Contains all locators and methods for login functionality
 */
public class LoginPage extends BasePage {
    
    // Locators
    private By emailField = By.id("txtEmail");
    private By passwordField = By.id("txtPassword");
    private By loginButton = By.id("btnLogin");
    private By forgotPasswordLink = By.linkText("Forgot Password?");
    private By errorMessage = By.xpath("//div[contains(@class, 'error') or contains(@class, 'alert')]");
    
    // Alternative locators
    private By emailFieldAlt = By.name("email");
    private By passwordFieldAlt = By.name("password");
    private By loginButtonAlt = By.xpath("//button[@type='submit' or contains(text(), 'Login') or contains(text(), 'Sign In')]");
    
    // Dashboard/Home indicators
    private By dashboardIndicator = By.xpath("//h1[contains(text(), 'Dashboard')] | //div[contains(@class, 'dashboard')]");
    
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Navigate to login page
     */
    public void navigateToLoginPage(String url) {
        driver.get(url);
        waitForPageLoad();
    }

    /**
     * Enter email
     */
    public void enterEmail(String email) {
        try {
            enterText(emailField, email);
        } catch (Exception e) {
            enterText(emailFieldAlt, email);
        }
    }

    /**
     * Enter password
     */
    public void enterPassword(String password) {
        try {
            enterText(passwordField, password);
        } catch (Exception e) {
            enterText(passwordFieldAlt, password);
        }
    }

    /**
     * Click login button
     */
    public void clickLogin() {
        try {
            clickElement(loginButton);
        } catch (Exception e) {
            clickElement(loginButtonAlt);
        }
        waitFor(3);
    }

    /**
     * Complete login with credentials
     */
    public void login(String email, String password) {
        enterEmail(email);
        enterPassword(password);
        clickLogin();
    }

    /**
     * Verify successful login
     */
    public boolean isLoginSuccessful() {
        try {
            waitFor(5);
            return getCurrentUrl().contains("dashboard") || 
                   getCurrentUrl().contains("home") || 
                   getCurrentUrl().toLowerCase().contains("main") ||
                   isElementDisplayed(dashboardIndicator);
        } catch (Exception e) {
            String currentUrl = getCurrentUrl().toLowerCase();
            return !currentUrl.contains("login") && 
                   (currentUrl.contains("dashboard") || 
                    currentUrl.contains("home") || 
                    currentUrl.contains("main"));
        }
    }

    /**
     * Verify login page loaded
     */
    public boolean isLoginPageLoaded() {
        try {
            return getCurrentUrl().contains("login") || 
                   isElementDisplayed(emailField) || 
                   isElementDisplayed(emailFieldAlt);
        } catch (Exception e) {
            return getCurrentUrl().toLowerCase().contains("login");
        }
    }

    /**
     * Get current page URL
     */
    public String getPageUrl() {
        return getCurrentUrl();
    }

    /**
     * Check if error message is displayed
     */
    public boolean isErrorMessageDisplayed() {
        try {
            return isElementDisplayed(errorMessage);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get error message text
     */
    public String getErrorMessage() {
        try {
            return getText(errorMessage);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Click forgot password link
     */
    public void clickForgotPassword() {
        try {
            clickElement(forgotPasswordLink);
        } catch (Exception e) {
            System.out.println("Forgot password link not found");
        }
    }
}
