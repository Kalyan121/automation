package com.calley.pages;

import com.calley.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * RegistrationPage class - Page Object Model for Registration page
 * Contains all locators and methods for registration functionality
 */
public class RegistrationPage extends BasePage {
    
    // Locators
    private By firstNameField = By.id("txtFirstName");
    private By lastNameField = By.id("txtLastName");
    private By emailField = By.id("txtEmail");
    private By phoneField = By.id("txtPhone");
    private By passwordField = By.id("txtPassword");
    private By companyField = By.id("txtCompany");
    private By termsCheckbox = By.id("chkTerms");
    private By signUpButton = By.id("btnSignUp");
    private By calleyTeamsPlanOption = By.xpath("//div[contains(@class, 'plan-card')]//h3[text()='Calley Teams']//ancestor::div[contains(@class, 'plan-card')]//button");
    private By successMessage = By.xpath("//div[contains(@class, 'success-message') or contains(text(), 'Registration successful')]");
    
    // Alternative locators (in case IDs are different)
    private By firstNameFieldAlt = By.name("firstName");
    private By lastNameFieldAlt = By.name("lastName");
    private By emailFieldAlt = By.name("email");
    private By phoneFieldAlt = By.name("phone");
    private By passwordFieldAlt = By.name("password");
    private By companyFieldAlt = By.name("company");
    private By submitButtonAlt = By.xpath("//button[@type='submit' or contains(text(), 'Sign Up')]");
    
    public RegistrationPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Navigate to registration page
     */
    public void navigateToRegistrationPage(String url) {
        driver.get(url);
        waitForPageLoad();
    }

    /**
     * Enter first name
     */
    public void enterFirstName(String firstName) {
        try {
            enterText(firstNameField, firstName);
        } catch (Exception e) {
            enterText(firstNameFieldAlt, firstName);
        }
    }

    /**
     * Enter last name
     */
    public void enterLastName(String lastName) {
        try {
            enterText(lastNameField, lastName);
        } catch (Exception e) {
            enterText(lastNameFieldAlt, lastName);
        }
    }

    /**
     * Enter email
     */
    public void enterEmail(String email) {
        try {
            enterText(emailField, email);
        } catch (Exception e) {
            enterText(emailFieldAlt, email);
        }
    }

    /**
     * Enter phone number
     */
    public void enterPhone(String phone) {
        try {
            enterText(phoneField, phone);
        } catch (Exception e) {
            enterText(phoneFieldAlt, phone);
        }
    }

    /**
     * Enter password
     */
    public void enterPassword(String password) {
        try {
            enterText(passwordField, password);
        } catch (Exception e) {
            enterText(passwordFieldAlt, password);
        }
    }

    /**
     * Enter company name
     */
    public void enterCompany(String company) {
        try {
            enterText(companyField, company);
        } catch (Exception e) {
            enterText(companyFieldAlt, company);
        }
    }

    /**
     * Accept terms and conditions
     */
    public void acceptTerms() {
        try {
            if (!driver.findElement(termsCheckbox).isSelected()) {
                clickElement(termsCheckbox);
            }
        } catch (Exception e) {
            System.out.println("Terms checkbox not found or already checked");
        }
    }

    /**
     * Click sign up button
     */
    public void clickSignUp() {
        try {
            clickElement(signUpButton);
        } catch (Exception e) {
            clickElement(submitButtonAlt);
        }
        waitFor(3);
    }

    /**
     * Select Calley Teams plan
     */
    public void selectCalleyTeamsPlan() {
        try {
            waitFor(2);
            clickElement(calleyTeamsPlanOption);
            waitFor(2);
        } catch (Exception e) {
            System.out.println("Calley Teams plan selection not found or not required");
        }
    }

    /**
     * Complete registration with all details
     */
    public void completeRegistration(String firstName, String lastName, String email, 
                                     String phone, String password, String company) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterEmail(email);
        enterPhone(phone);
        enterPassword(password);
        enterCompany(company);
        acceptTerms();
        clickSignUp();
    }

    /**
     * Verify registration success
     */
    public boolean isRegistrationSuccessful() {
        try {
            waitFor(3);
            return isElementDisplayed(successMessage) || 
                   getCurrentUrl().contains("dashboard") || 
                   getCurrentUrl().contains("home") ||
                   getCurrentUrl().contains("plan");
        } catch (Exception e) {
            return getCurrentUrl().contains("dashboard") || 
                   getCurrentUrl().contains("home") ||
                   getCurrentUrl().contains("plan");
        }
    }

    /**
     * Get current page URL
     */
    public String getPageUrl() {
        return getCurrentUrl();
    }

    /**
     * Verify registration page loaded
     */
    public boolean isRegistrationPageLoaded() {
        try {
            return getCurrentUrl().contains("registration") || 
                   isElementDisplayed(firstNameField) || 
                   isElementDisplayed(firstNameFieldAlt);
        } catch (Exception e) {
            return getCurrentUrl().contains("registration");
        }
    }
}
