package com.calley.tests;

import com.calley.base.BaseTest;
import com.calley.pages.CSVUploadPage;
import com.calley.pages.DashboardPage;
import com.calley.pages.LoginPage;
import com.calley.utils.ExtentReportManager;
import com.calley.utils.TestDataReader;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.File;

/**
 * CSVUploadTest class - Contains all test cases for CSV upload functionality
 */
public class CSVUploadTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private CSVUploadPage csvUploadPage;
    private TestDataReader testData;
    private String csvFilePath;

    @BeforeMethod
    public void setupTest() {
        // Initialize page objects
        loginPage = new LoginPage(driver);
        dashboardPage = new DashboardPage(driver);
        csvUploadPage = new CSVUploadPage(driver);
        testData = new TestDataReader();

        // Set CSV file path
        csvFilePath = System.getProperty("user.dir") + "/src/test/resources/testdata/SampleFile.csv";

        // Verify CSV file exists
        File csvFile = new File(csvFilePath);
        if (!csvFile.exists()) {
            System.out.println("CSV file not found at: " + csvFilePath);
            System.out.println("Creating sample CSV file...");
            createSampleCSVFile();
        }

        // Login before each test
        String email = testData.getTestData("loginEmail");
        String password = testData.getTestData("loginPassword");

        if (email == null || email.isEmpty()) {
            email = "test@example.com";
            password = "Test@1234";
        }

        loginPage.navigateToLoginPage(config.getLoginUrl());
        loginPage.login(email, password);

        // Wait for dashboard to load
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 1, description = "Test CSV file upload functionality")
    public void testCSVUpload() {
        ExtentReportManager.createTest("CSV Upload Test", 
            "Verify user can upload CSV file successfully");

        try {
            String listName = testData.getListName() + "_" + System.currentTimeMillis();

            ExtentReportManager.logInfo("Test Data - List Name: " + listName);
            ExtentReportManager.logInfo("CSV File Path: " + csvFilePath);

            // Navigate to Power Import
            ExtentReportManager.logInfo("Navigating to Power Import page");
            csvUploadPage.navigateToPowerImport();
            ExtentReportManager.logPass("Navigated to Power Import page");

            // Upload CSV
            ExtentReportManager.logInfo("Uploading CSV file");
            csvUploadPage.uploadCSV(listName, csvFilePath);
            ExtentReportManager.logPass("CSV file uploaded and processed");

            // Verify upload success
            ExtentReportManager.logInfo("Verifying CSV upload");
            boolean isUploadSuccessful = csvUploadPage.isUploadSuccessful();
            Assert.assertTrue(isUploadSuccessful, "CSV upload was not successful");
            ExtentReportManager.logPass("CSV uploaded successfully");

            System.out.println("CSV Upload Test Passed!");
            System.out.println("List Name: " + listName);

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("CSV upload test failed: " + e.getMessage());
        }
    }

    @Test(priority = 2, description = "Test Power Import page accessibility")
    public void testPowerImportPageAccessibility() {
        ExtentReportManager.createTest("Power Import Page Accessibility Test", 
            "Verify Power Import page is accessible after login");

        try {
            ExtentReportManager.logInfo("Navigating to Power Import page");
            csvUploadPage.navigateToPowerImport();

            ExtentReportManager.logInfo("Verifying page load");
            boolean isPageLoaded = csvUploadPage.isPowerImportPageLoaded();
            Assert.assertTrue(isPageLoaded, "Power Import page did not load properly");

            String currentUrl = csvUploadPage.getPageUrl();
            ExtentReportManager.logInfo("Current URL: " + currentUrl);

            ExtentReportManager.logPass("Power Import page is accessible");
            System.out.println("Power Import Page Accessibility Test Passed!");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            Assert.fail("Power Import page accessibility test failed: " + e.getMessage());
        }
    }

    /**
     * Helper method to create sample CSV file if it doesn't exist
     */
    private void createSampleCSVFile() {
        // This will be handled by the separate CSV file creation
        System.out.println("Please ensure SampleFile.csv exists in src/test/resources/testdata/");
    }
}
