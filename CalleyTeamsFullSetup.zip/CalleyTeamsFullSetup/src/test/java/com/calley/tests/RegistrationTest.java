package com.calley.tests;

import com.calley.base.BaseTest;
import com.calley.pages.DashboardPage;
import com.calley.pages.RegistrationPage;
import com.calley.utils.ExtentReportManager;
import com.calley.utils.TestDataReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * RegistrationTest class - Contains all test cases for user registration
 */
public class RegistrationTest extends BaseTest {

    @Test(priority = 1, description = "Test user registration with valid data and Calley Teams plan selection")
    public void testUserRegistrationWithCalleyTeams() {
        ExtentReportManager.createTest("User Registration Test", 
            "Verify user can register successfully and select Calley Teams plan");

        try {
            // Test data
            TestDataReader testData = new TestDataReader();
            String firstName = testData.getFirstName();
            String lastName = testData.getLastName();
            String email = testData.getEmail();
            String phone = testData.getPhone();
            String password = testData.getPassword();
            String company = testData.getCompany();

            ExtentReportManager.logInfo("Test Data - Email: " + email);
            ExtentReportManager.logInfo("Test Data - Name: " + firstName + " " + lastName);

            // Initialize page object
            RegistrationPage registrationPage = new RegistrationPage(driver);

            // Navigate to registration page
            ExtentReportManager.logInfo("Navigating to registration page");
            registrationPage.navigateToRegistrationPage(config.getRegistrationUrl());
            Assert.assertTrue(registrationPage.isRegistrationPageLoaded(), 
                "Registration page did not load");
            ExtentReportManager.logPass("Registration page loaded successfully");

            // Fill registration form
            ExtentReportManager.logInfo("Filling registration form");
            registrationPage.completeRegistration(firstName, lastName, email, phone, password, company);
            ExtentReportManager.logPass("Registration form filled successfully");

            // Select Calley Teams plan
            ExtentReportManager.logInfo("Selecting Calley Teams plan");
            registrationPage.selectCalleyTeamsPlan();
            ExtentReportManager.logPass("Calley Teams plan selected");

            // Verify registration success
            ExtentReportManager.logInfo("Verifying registration success");
            boolean isSuccess = registrationPage.isRegistrationSuccessful();
            Assert.assertTrue(isSuccess, "Registration was not successful");
            ExtentReportManager.logPass("User registered successfully with Calley Teams plan");

            System.out.println("Registration Test Passed!");
            System.out.println("Registered Email: " + email);
            System.out.println("Password: " + password);

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Registration test failed: " + e.getMessage());
        }
    }

    @Test(priority = 2, description = "Test user registration page accessibility")
    public void testRegistrationPageAccessibility() {
        ExtentReportManager.createTest("Registration Page Accessibility Test", 
            "Verify registration page is accessible and loads correctly");

        try {
            RegistrationPage registrationPage = new RegistrationPage(driver);

            ExtentReportManager.logInfo("Navigating to registration page");
            registrationPage.navigateToRegistrationPage(config.getRegistrationUrl());

            ExtentReportManager.logInfo("Verifying page load");
            Assert.assertTrue(registrationPage.isRegistrationPageLoaded(), 
                "Registration page did not load properly");

            String currentUrl = registrationPage.getPageUrl();
            ExtentReportManager.logInfo("Current URL: " + currentUrl);
            Assert.assertTrue(currentUrl.contains("registration"), 
                "URL does not contain 'registration'");

            ExtentReportManager.logPass("Registration page is accessible");
            System.out.println("Registration Page Accessibility Test Passed!");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            Assert.fail("Registration page accessibility test failed: " + e.getMessage());
        }
    }
}
