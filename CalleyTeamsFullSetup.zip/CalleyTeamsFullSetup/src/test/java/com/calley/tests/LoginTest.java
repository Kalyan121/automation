package com.calley.tests;

import com.calley.base.BaseTest;
import com.calley.pages.DashboardPage;
import com.calley.pages.LoginPage;
import com.calley.utils.ExtentReportManager;
import com.calley.utils.TestDataReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * LoginTest class - Contains all test cases for user login functionality
 */
public class LoginTest extends BaseTest {

    @Test(priority = 1, description = "Test user login with valid credentials")
    public void testValidLogin() {
        ExtentReportManager.createTest("Valid Login Test", 
            "Verify user can login with valid credentials");

        try {
            // Test data
            TestDataReader testData = new TestDataReader();
            String email = testData.getTestData("loginEmail");
            String password = testData.getTestData("loginPassword");

            // Use default credentials if not provided
            if (email == null || email.isEmpty()) {
                email = "test@example.com"; // Replace with actual test credentials
                password = "Test@1234";
            }

            ExtentReportManager.logInfo("Test Data - Email: " + email);

            // Initialize page objects
            LoginPage loginPage = new LoginPage(driver);
            DashboardPage dashboardPage = new DashboardPage(driver);

            // Navigate to login page
            ExtentReportManager.logInfo("Navigating to login page");
            loginPage.navigateToLoginPage(config.getLoginUrl());
            Assert.assertTrue(loginPage.isLoginPageLoaded(), "Login page did not load");
            ExtentReportManager.logPass("Login page loaded successfully");

            // Perform login
            ExtentReportManager.logInfo("Entering login credentials");
            loginPage.login(email, password);
            ExtentReportManager.logPass("Login credentials entered");

            // Verify successful login
            ExtentReportManager.logInfo("Verifying login success");
            boolean isLoginSuccessful = loginPage.isLoginSuccessful() || dashboardPage.isDashboardLoaded();
            Assert.assertTrue(isLoginSuccessful, "Login was not successful");
            ExtentReportManager.logPass("User logged in successfully");

            System.out.println("Login Test Passed!");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Login test failed: " + e.getMessage());
        }
    }

    @Test(priority = 2, description = "Test login page accessibility")
    public void testLoginPageAccessibility() {
        ExtentReportManager.createTest("Login Page Accessibility Test", 
            "Verify login page is accessible and loads correctly");

        try {
            LoginPage loginPage = new LoginPage(driver);

            ExtentReportManager.logInfo("Navigating to login page");
            loginPage.navigateToLoginPage(config.getLoginUrl());

            ExtentReportManager.logInfo("Verifying page load");
            Assert.assertTrue(loginPage.isLoginPageLoaded(), 
                "Login page did not load properly");

            String currentUrl = loginPage.getPageUrl();
            ExtentReportManager.logInfo("Current URL: " + currentUrl);
            Assert.assertTrue(currentUrl.toLowerCase().contains("login"), 
                "URL does not contain 'login'");

            ExtentReportManager.logPass("Login page is accessible");
            System.out.println("Login Page Accessibility Test Passed!");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            Assert.fail("Login page accessibility test failed: " + e.getMessage());
        }
    }

    @Test(priority = 3, description = "Test dashboard access after login")
    public void testDashboardAccessAfterLogin() {
        ExtentReportManager.createTest("Dashboard Access Test", 
            "Verify user can access dashboard after successful login");

        try {
            // Test data
            TestDataReader testData = new TestDataReader();
            String email = testData.getTestData("loginEmail");
            String password = testData.getTestData("loginPassword");

            if (email == null || email.isEmpty()) {
                email = "test@example.com";
                password = "Test@1234";
            }

            LoginPage loginPage = new LoginPage(driver);
            DashboardPage dashboardPage = new DashboardPage(driver);

            // Login
            ExtentReportManager.logInfo("Performing login");
            loginPage.navigateToLoginPage(config.getLoginUrl());
            loginPage.login(email, password);
            ExtentReportManager.logPass("Login performed");

            // Verify dashboard access
            ExtentReportManager.logInfo("Verifying dashboard access");
            Assert.assertTrue(dashboardPage.isDashboardLoaded(), 
                "Dashboard did not load after login");
            ExtentReportManager.logPass("Dashboard accessed successfully");

            System.out.println("Dashboard Access Test Passed!");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            Assert.fail("Dashboard access test failed: " + e.getMessage());
        }
    }
}
