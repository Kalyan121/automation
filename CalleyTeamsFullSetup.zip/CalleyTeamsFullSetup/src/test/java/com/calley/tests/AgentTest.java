package com.calley.tests;

import com.calley.base.BaseTest;
import com.calley.pages.AgentPage;
import com.calley.pages.DashboardPage;
import com.calley.pages.LoginPage;
import com.calley.utils.ExtentReportManager;
import com.calley.utils.TestDataReader;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * AgentTest class - Contains all test cases for agent management functionality
 */
public class AgentTest extends BaseTest {

    private LoginPage loginPage;
    private DashboardPage dashboardPage;
    private AgentPage agentPage;
    private TestDataReader testData;

    @BeforeMethod
    public void loginBeforeTest() {
        // Initialize page objects
        loginPage = new LoginPage(driver);
        dashboardPage = new DashboardPage(driver);
        agentPage = new AgentPage(driver);
        testData = new TestDataReader();

        // Login before each test
        String email = testData.getTestData("loginEmail");
        String password = testData.getTestData("loginPassword");

        if (email == null || email.isEmpty()) {
            email = "test@example.com";
            password = "Test@1234";
        }

        loginPage.navigateToLoginPage(config.getLoginUrl());
        loginPage.login(email, password);

        // Wait for dashboard to load
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 1, description = "Test adding a new agent")
    public void testAddAgent() {
        ExtentReportManager.createTest("Add Agent Test", 
            "Verify user can add a new agent successfully");

        try {
            String agentName = testData.getAgentName();
            String agentEmail = testData.getAgentEmail();

            ExtentReportManager.logInfo("Test Data - Agent Name: " + agentName);
            ExtentReportManager.logInfo("Test Data - Agent Email: " + agentEmail);

            // Navigate to agents page
            ExtentReportManager.logInfo("Navigating to agents page");
            agentPage.navigateToAgentsPage();
            ExtentReportManager.logPass("Navigated to agents page");

            // Add new agent
            ExtentReportManager.logInfo("Adding new agent");
            agentPage.addAgent(agentName, agentEmail);
            ExtentReportManager.logPass("Agent details entered and submitted");

            // Verify agent added successfully
            ExtentReportManager.logInfo("Verifying agent addition");
            boolean isAgentAdded = agentPage.isAgentAddedSuccessfully();
            Assert.assertTrue(isAgentAdded, "Agent was not added successfully");
            ExtentReportManager.logPass("Agent added successfully");

            System.out.println("Add Agent Test Passed!");
            System.out.println("Agent Email: " + agentEmail);

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Add agent test failed: " + e.getMessage());
        }
    }

    @Test(priority = 2, description = "Test agents page accessibility")
    public void testAgentsPageAccessibility() {
        ExtentReportManager.createTest("Agents Page Accessibility Test", 
            "Verify agents page is accessible after login");

        try {
            ExtentReportManager.logInfo("Navigating to agents page");
            agentPage.navigateToAgentsPage();

            ExtentReportManager.logInfo("Verifying page load");
            boolean isPageLoaded = agentPage.isAgentsPageLoaded();
            Assert.assertTrue(isPageLoaded, "Agents page did not load properly");

            String currentUrl = agentPage.getPageUrl();
            ExtentReportManager.logInfo("Current URL: " + currentUrl);

            ExtentReportManager.logPass("Agents page is accessible");
            System.out.println("Agents Page Accessibility Test Passed!");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            Assert.fail("Agents page accessibility test failed: " + e.getMessage());
        }
    }

    @Test(priority = 3, description = "Test adding agent with phone number")
    public void testAddAgentWithPhone() {
        ExtentReportManager.createTest("Add Agent with Phone Test", 
            "Verify user can add agent with phone number");

        try {
            String agentName = testData.getAgentName() + " 2";
            String agentEmail = "agent2." + System.currentTimeMillis() + "@test.com";
            String agentPhone = testData.getPhone();

            ExtentReportManager.logInfo("Test Data - Agent Name: " + agentName);
            ExtentReportManager.logInfo("Test Data - Agent Email: " + agentEmail);
            ExtentReportManager.logInfo("Test Data - Agent Phone: " + agentPhone);

            // Navigate to agents page
            ExtentReportManager.logInfo("Navigating to agents page");
            agentPage.navigateToAgentsPage();

            // Add new agent with phone
            ExtentReportManager.logInfo("Adding new agent with phone");
            agentPage.addAgent(agentName, agentEmail, agentPhone);
            ExtentReportManager.logPass("Agent details with phone entered and submitted");

            // Verify agent added successfully
            ExtentReportManager.logInfo("Verifying agent addition");
            boolean isAgentAdded = agentPage.isAgentAddedSuccessfully();
            Assert.assertTrue(isAgentAdded, "Agent with phone was not added successfully");
            ExtentReportManager.logPass("Agent with phone added successfully");

            System.out.println("Add Agent with Phone Test Passed!");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Add agent with phone test failed: " + e.getMessage());
        }
    }
}
