package com.calley.tests;

import com.calley.base.BaseTest;
import com.calley.pages.*;
import com.calley.utils.ExtentReportManager;
import com.calley.utils.TestDataReader;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;

/**
 * FullSetupTest class - Complete end-to-end test for Calley Teams Setup
 * This test covers: Registration -> Login -> Add Agents -> Upload CSV
 */
public class FullSetupTest extends BaseTest {

    private String registeredEmail;
    private String registeredPassword;

    @Test(priority = 1, description = "Complete Calley Teams Setup - Registration to CSV Upload")
    public void testCompleteCalleyTeamsSetup() {
        ExtentReportManager.createTest("Complete Calley Teams Setup Test", 
            "End-to-end test: Registration, Login, Add Agent, and CSV Upload");

        // Test data
        TestDataReader testData = new TestDataReader();
        String firstName = testData.getFirstName();
        String lastName = testData.getLastName();
        registeredEmail = testData.getEmail();
        String phone = testData.getPhone();
        registeredPassword = testData.getPassword();
        String company = testData.getCompany();
        String agentName = testData.getAgentName();
        String agentEmail = testData.getAgentEmail();
        String listName = testData.getListName() + "_" + System.currentTimeMillis();
        String csvFilePath = System.getProperty("user.dir") + "/src/test/resources/testdata/SampleFile.csv";

        try {
            // Step 1: User Registration
            ExtentReportManager.logInfo("========== STEP 1: USER REGISTRATION ==========");
            ExtentReportManager.logInfo("Registration Email: " + registeredEmail);
            
            RegistrationPage registrationPage = new RegistrationPage(driver);
            registrationPage.navigateToRegistrationPage(config.getRegistrationUrl());
            
            Assert.assertTrue(registrationPage.isRegistrationPageLoaded(), 
                "Registration page did not load");
            ExtentReportManager.logPass("Registration page loaded");
            
            registrationPage.completeRegistration(firstName, lastName, registeredEmail, 
                phone, registeredPassword, company);
            ExtentReportManager.logPass("Registration form submitted");
            
            registrationPage.selectCalleyTeamsPlan();
            ExtentReportManager.logPass("Calley Teams plan selected");
            
            Assert.assertTrue(registrationPage.isRegistrationSuccessful(), 
                "Registration failed");
            ExtentReportManager.logPass("✓ User registered successfully");
            
            // Wait for any post-registration processes
            Thread.sleep(5000);

            // Step 2: User Login
            ExtentReportManager.logInfo("========== STEP 2: USER LOGIN ==========");
            ExtentReportManager.logInfo("Login Email: " + registeredEmail);
            
            LoginPage loginPage = new LoginPage(driver);
            DashboardPage dashboardPage = new DashboardPage(driver);
            
            loginPage.navigateToLoginPage(config.getLoginUrl());
            Assert.assertTrue(loginPage.isLoginPageLoaded(), "Login page did not load");
            ExtentReportManager.logPass("Login page loaded");
            
            loginPage.login(registeredEmail, registeredPassword);
            ExtentReportManager.logPass("Login credentials entered");
            
            Thread.sleep(5000);
            
            boolean isLoggedIn = loginPage.isLoginSuccessful() || dashboardPage.isDashboardLoaded();
            Assert.assertTrue(isLoggedIn, "Login failed");
            ExtentReportManager.logPass("✓ User logged in successfully");

            // Step 3: Add Agent
            ExtentReportManager.logInfo("========== STEP 3: ADD AGENT ==========");
            ExtentReportManager.logInfo("Agent Name: " + agentName);
            ExtentReportManager.logInfo("Agent Email: " + agentEmail);
            
            AgentPage agentPage = new AgentPage(driver);
            agentPage.navigateToAgentsPage();
            ExtentReportManager.logPass("Navigated to agents page");
            
            agentPage.addAgent(agentName, agentEmail);
            ExtentReportManager.logPass("Agent details submitted");
            
            Assert.assertTrue(agentPage.isAgentAddedSuccessfully(), 
                "Agent addition failed");
            ExtentReportManager.logPass("✓ Agent added successfully");
            
            Thread.sleep(3000);

            // Step 4: Upload CSV
            ExtentReportManager.logInfo("========== STEP 4: CSV UPLOAD ==========");
            ExtentReportManager.logInfo("List Name: " + listName);
            ExtentReportManager.logInfo("CSV File: " + csvFilePath);
            
            // Verify CSV file exists
            File csvFile = new File(csvFilePath);
            Assert.assertTrue(csvFile.exists(), "CSV file not found at: " + csvFilePath);
            ExtentReportManager.logPass("CSV file found");
            
            CSVUploadPage csvUploadPage = new CSVUploadPage(driver);
            csvUploadPage.navigateToPowerImport();
            ExtentReportManager.logPass("Navigated to Power Import page");
            
            csvUploadPage.uploadCSV(listName, csvFilePath);
            ExtentReportManager.logPass("CSV file uploaded");
            
            Assert.assertTrue(csvUploadPage.isUploadSuccessful(), 
                "CSV upload failed");
            ExtentReportManager.logPass("✓ CSV uploaded successfully");

            // Test Summary
            ExtentReportManager.logInfo("========== TEST SUMMARY ==========");
            ExtentReportManager.logPass("✓ Registration completed");
            ExtentReportManager.logPass("✓ Login successful");
            ExtentReportManager.logPass("✓ Agent added");
            ExtentReportManager.logPass("✓ CSV uploaded");
            ExtentReportManager.logPass("========== ALL STEPS COMPLETED SUCCESSFULLY ==========");

            System.out.println("\n========================================");
            System.out.println("COMPLETE CALLEY TEAMS SETUP TEST PASSED!");
            System.out.println("========================================");
            System.out.println("Registered Email: " + registeredEmail);
            System.out.println("Password: " + registeredPassword);
            System.out.println("Agent Email: " + agentEmail);
            System.out.println("List Name: " + listName);
            System.out.println("========================================\n");

        } catch (Exception e) {
            ExtentReportManager.logFail("Test failed at some step: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Complete setup test failed: " + e.getMessage());
        }
    }
}
