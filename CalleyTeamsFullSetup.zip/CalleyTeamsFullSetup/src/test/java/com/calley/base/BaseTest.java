package com.calley.base;

import com.calley.utils.ConfigReader;
import com.calley.utils.ExtentReportManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BaseTest class contains setup and teardown methods for tests
 * All test classes should extend this class
 */
public class BaseTest {
    protected WebDriver driver;
    protected ConfigReader config;
    
    @BeforeSuite
    public void beforeSuite() {
        ExtentReportManager.initReports();
    }

    @BeforeMethod
    @Parameters({"browser"})
    public void setUp(@Optional("chrome") String browser) {
        // Load configuration
        config = new ConfigReader();
        
        // Initialize WebDriver based on browser parameter
        driver = initializeDriver(browser);
        
        // Set implicit wait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        
        // Maximize window
        driver.manage().window().maximize();
        
        // Delete all cookies
        driver.manage().deleteAllCookies();
    }

    /**
     * Initialize WebDriver based on browser type
     */
    private WebDriver initializeDriver(String browser) {
        WebDriver driver;
        
        switch (browser.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--start-maximized");
                chromeOptions.addArguments("--disable-notifications");
                chromeOptions.addArguments("--disable-popup-blocking");
                driver = new ChromeDriver(chromeOptions);
                break;
                
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
                
            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
                
            default:
                System.out.println("Browser not supported. Using Chrome as default.");
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver();
        }
        
        return driver;
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    
    @AfterSuite
    public void afterSuite() {
        ExtentReportManager.flushReports();
    }
}
